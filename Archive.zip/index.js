const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
require('dotenv').config();

const app = express(); 
const PORT = process.env.PORT || 4000;

const agregarMaterialesRoute = require('./routes/agregar.materiales.route');
const registrarUsuarioRoute = require('./routes/registrar.usuario.route');
const registrarMaterialesRoute = require('./routes/registrar.materiales.route');
const registrarNivelesRoute = require('./routes/registrar.niveles.route');
const registrarListasRoute = require('./routes/registrar.listas.route');
const registrarCategoriasRoute = require('./routes/registrar.categorias.route');

mongoose.connect(process.env.MONGODB_URI || 'mongodb+srv://mcarvajalt:maria123@cluster0.7yr8d.mongodb.net/utiles?retryWrites=true&w=majority&appName=Cluster0')
  .then(() => console.log('✅ Conexión exitosa a MongoDB Atlas'))
  .catch(err => console.error('❌ Error de conexión:', err.message));

app.use(cors());
app.use(express.json());

app.use(express.static(__dirname));

app.use('/agregarMateriales', agregarMaterialesRoute);
app.use('/registrarUsuario', registrarUsuarioRoute);
app.use('/registrarMateriales', registrarMaterialesRoute);
app.use('/registrarNiveles', registrarNivelesRoute);
app.use('/registrarListas', registrarListasRoute);
app.use('/registrarCategorias', registrarCategoriasRoute);

app.get('/', (req, res) => {
    res.send('Servidor en funcionamiento');
});

app.listen(PORT, () => {
    console.log(`Servidor corriendo en http://localhost:${PORT}`);
});



