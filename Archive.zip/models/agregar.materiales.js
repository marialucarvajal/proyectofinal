const mongoose = require('mongoose');

const materialSchema = new mongoose.Schema({
    lista: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Lista',  // Debe coincidir con el nombre del modelo exportado en registrar.listas.js
        required: true
    },
    material: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'MaterialEscolar',  // Verifica el nombre exacto del modelo
        required: true
    },
    cantidad: {
        type: Number,
        required: true
    },
    observaciones: {
        type: String,
        required: false
    }
});

module.exports = mongoose.model('Material', materialSchema);


