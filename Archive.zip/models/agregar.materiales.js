// models/agregar.materiales.js
const mongoose = require('mongoose');

const materialSchema = new mongoose.Schema({
    lista: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Lista',
        required: true
    },
    material: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'MaterialEscolar',
        required: true
    },
    cantidad: {
        type: Number,
        required: true
    },
    observaciones: {
        type: String,
        required: false
    }
}, { collection: 'materials' });

// Exporta como 'Material' (asegúrate que coincida con lo que usas en las rutas)
module.exports = mongoose.model('Material', materialSchema);


