const mongoose = require('mongoose');

const materialSchema = new mongoose.Schema({
    lista: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Lista',
        required: true
    },
    material: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'MaterialEscolar',
        required: true,
        transform: (v) => v === null ? undefined : v // Transforma null a undefined
    },
    cantidad: {
        type: Number,
        required: true
    },
    observaciones: {
        type: String,
        required: false
    }
}, { 
    collection: 'materials',
    toJSON: { virtuals: true },
    toObject: { virtuals: true }
});

module.exports = mongoose.model('MaterialLista', materialSchema);


