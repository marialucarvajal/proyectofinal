const mongoose = require('mongoose');

const materialSchema = new mongoose.Schema({
    lista: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Lista',
        required: true
    },
    material: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'MaterialEscolar',
        required: true
    },
    cantidad: {
        type: Number,
        required: true
    },
    observaciones: {
        type: String,
        required: false
    }
}, { 
    collection: 'materials' // Esto fuerza a usar esta colección exacta
});

// Cambia el nombre del modelo a 'MaterialLista' para evitar conflictos
module.exports = mongoose.model('MaterialLista', materialSchema);


