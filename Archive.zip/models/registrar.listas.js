const mongoose = require('mongoose');

const listaSchema = new mongoose.Schema({
    nombre: {
        type: String,
        required: true
    },
    fechaInicio: {
        type: Date,
        required: true
    },
    fechaFin: {
        type: Date,
        required: true
    }
});

module.exports = mongoose.model('Lista', listaSchema);

