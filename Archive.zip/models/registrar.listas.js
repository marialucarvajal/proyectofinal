const mongoose = require('mongoose');

const schemaLista = new mongoose.Schema({
    nombreLista: {  
        type: String,
        required: true
    },
    nivelEducativo: {
        type: String,
        required: true
    },
    fechaCreacion: {
        type: Date,
        required: true
    },
    estado: {
        type: String,
        default: "activo" // Cambiado de Boolean a String para coincidir con tus datos
    }
});

module.exports = mongoose.model('Lista', schemaLista);
