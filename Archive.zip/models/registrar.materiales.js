const mongoose = require('mongoose');

const schemaMaterialesEscolares = new mongoose.Schema({
    nombre: {
        type: String,
        required: true,
        trim: true,
    },
    descripcion: {
        type: String,
        required: true,
        trim: true,
    },
    categoria: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Categoria',
        required: true,
    },
    unidadMedida: {
        type: String,
        required: true,
    },
    estado: {
        type: Boolean,
        default: true,
    },
}, { 
    collection: 'materialescolares' // ¡Asegúrate que coincida exactamente!
});

module.exports = mongoose.model('MaterialEscolar', schemaMaterialesEscolares);

