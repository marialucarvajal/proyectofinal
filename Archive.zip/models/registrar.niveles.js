const mongoose = require('mongoose');


const schemaNivel = new mongoose.Schema({
    nivel: {
        type: String,
        required: true,
        unique: true
    },
    descripcion: {
        type: String,
        required: true
    },
    estado: {
        type: String,
        required: true,
        default: "activo" 
    }
});


const Nivel = mongoose.model('Nivel', schemaNivel);
module.exports = Nivel;