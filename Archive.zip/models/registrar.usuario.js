const mongoose = require('mongoose');

const schemaUsuario = new mongoose.Schema({
    nombre: {
        type: String,
        required: true
    },
    cedula: {
        type: String,
        required: true,
        unique: true
    },
    correo: {
        type: String,
        required: true,
        unique: true
    },
    contrasena: {
        type: String,
        required: true
    },
    rol: {
        type: String,
        enum: ['Maestro', 'Padre de familia'],
        required: true
    },
    estadoCuenta: {
        type: String,
        default: true
    }
});


const Usuario = mongoose.model('Usuario', schemaUsuario);
module.exports = Usuario;