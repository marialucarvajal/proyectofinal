const mongoose = require('mongoose');
const express = require('express');
const router = express.Router();
const Material = require('../models/agregar.materiales');
const Lista = require('../models/registrar.listas');
const MaterialEscolar = require('../models/registrar.materiales');

// Ruta POST para agregar materiales (ya está correcta)
router.post('/', async (req, res) => {
    const { lista, material, cantidad, observaciones } = req.body;

    if (!lista || !material || !cantidad) {
        return res.status(400).json({ msj: 'Por favor llenar los campos son obligatorios.' });
    }

    try {
        const listaObj = await Lista.findById(lista);
        if (!listaObj) {
            return res.status(400).json({ msj: 'Lista no encontrada.' });
        }

        const materialObj = await MaterialEscolar.findById(material);
        if (!materialObj) {
            return res.status(400).json({ msj: 'Material no encontrado.' });
        }

        const nuevoMaterial = new Material({
            lista: listaObj._id,
            material: materialObj._id,
            cantidad,
            observaciones
        });

        await nuevoMaterial.save();
        res.status(201).json(nuevoMaterial);
    } catch (error) {
        res.status(400).json({ msj: error.message });
    }
});

// Ruta GET unificada y corregida
router.get('/', async (req, res) => {
    try {
        const materiales = await Material.find()
            .populate({
                path: 'lista',
                select: 'nombreLista nivelEducativo'
            })
            .populate({
                path: 'material',
                select: 'nombre descripcion'
            })
            .lean();

        const resultados = materiales.map(item => ({
            ...item,
            material: item.material || { nombre: 'No disponible', descripcion: '' }
        }));

        res.json(resultados);
    } catch (error) {
        console.error('Error en GET /:', error);
        res.status(500).json({
            success: false,
            message: "Error al obtener materiales",
            error: error.message,
            suggestion: "Verifique que los modelos estén correctamente registrados y las colecciones existan"
        });
    }
});

module.exports = router;



