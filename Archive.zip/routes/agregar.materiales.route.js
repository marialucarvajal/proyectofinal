const mongoose = require('mongoose');
const express = require('express');
const router = express.Router();
const Material = require('../models/agregar.materiales');
const Lista = require('../models/registrar.listas'); // Asegúrate de tener el modelo Lista
const MaterialEscolar = require('../models/registrar.materiales');

// Ruta POST para agregar materiales
router.post('/', async (req, res) => {
    const { lista, material, cantidad, observaciones } = req.body;

    if (!lista || !material || !cantidad) {
        return res.status(400).json({ msj: 'Por favor llenar los campos son obligatorios.' });
    }

    try {
        // Buscar la lista por ID
        const listaObj = await Lista.findById(lista);
        if (!listaObj) {
            return res.status(400).json({ msj: 'Lista no encontrada.' });
        }

        // Buscar el material por ID
        const materialObj = await MaterialEscolar.findById(material);
        if (!materialObj) {
            return res.status(400).json({ msj: 'Material no encontrado.' });
        }

        const nuevoMaterial = new Material({
            lista: listaObj._id,  // Usar el _id de la lista
            material: materialObj._id, // Usar el _id del material
            cantidad,
            observaciones
        });

        await nuevoMaterial.save();
        res.status(201).json(nuevoMaterial);
    } catch (error) {
        res.status(400).json({ msj: error.message });
    }
});


router.get('/', async (req, res) => {
    try {
        // Verificación de modelos
        if (!mongoose.modelNames().includes('MaterialEscolar')) {
            throw new Error('Modelo MaterialEscolar no registrado');
        }

        // Consulta con populate forzado
        const materiales = await mongoose.model('MaterialLista').find()
            .populate({
                path: 'lista',
                select: 'nombreLista nivelEducativo'
            })
            .populate({
                path: 'material',
                model: 'MaterialEscolar', // Especifica explícitamente el modelo
                select: 'nombre descripcion',
                options: { allowNull: true } // Permite populate con null
            })
            .lean();

        // Transformar null a objeto vacío para el frontend
        const materialesTransformados = materiales.map(item => ({
            ...item,
            material: item.material || { nombre: 'No disponible', descripcion: '' }
        }));

        res.json(materialesTransformados);
    } catch (error) {
        console.error('Error en GET /:', error);
        res.status(500).json({ 
            success: false,
            message: "Error al obtener materiales",
            error: error.message
        });
    }
});

router.get('/fix-material', async (req, res) => {
    try {
      const doc = {
        _id: new mongoose.Types.ObjectId("6807e8a21363f8a047671920"),
        nombre: "Cuaderno",
        descripcion: "100 páginas",
        categoria: new mongoose.Types.ObjectId("6807e3747e73fe4b73a971b7"),
        unidadMedida: "unidad",
        estado: true,
        __v: 0
      };
  
      // Opción para omitir validación
      const options = { bypassDocumentValidation: true };
      
      const result = await mongoose.connection.db.collection('materialescolares')
        .insertOne(doc, options);
  
      res.json({
        success: true,
        message: "Material creado exitosamente",
        insertedId: result.insertedId
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        error: error.message,
        code: error.code
      });
    }
  });

  router.get('/find-material', async (req, res) => {
    try {
      // Buscar en todas las colecciones posibles
      const collections = await mongoose.connection.db.listCollections().toArray();
      let materialLocation = null;
  
      for (const collection of collections) {
        const found = await mongoose.connection.db
          .collection(collection.name)
          .findOne({ _id: new mongoose.Types.ObjectId("6807e8a21363f8a047671920") });
  
        if (found) {
          materialLocation = collection.name;
          break;
        }
      }
  
      res.json({
        success: true,
        location: materialLocation || "No encontrado en ninguna colección"
      });
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

module.exports = router;



