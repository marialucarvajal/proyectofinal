const express = require('express');
const router = express.Router();
const Material = require('../models/agregar.materiales');
const Lista = require('../models/registrar.listas'); // Asegúrate de tener el modelo Lista
const MaterialEscolar = require('../models/registrar.materiales');

// Ruta POST para agregar materiales
router.post('/', async (req, res) => {
    const { lista, material, cantidad, observaciones } = req.body;

    if (!lista || !material || !cantidad) {
        return res.status(400).json({ msj: 'Por favor llenar los campos son obligatorios.' });
    }

    try {
        // Buscar la lista por ID
        const listaObj = await Lista.findById(lista);
        if (!listaObj) {
            return res.status(400).json({ msj: 'Lista no encontrada.' });
        }

        // Buscar el material por ID
        const materialObj = await MaterialModelo.findById(material);
        if (!materialObj) {
            return res.status(400).json({ msj: 'Material no encontrado.' });
        }

        const nuevoMaterial = new Material({
            lista: listaObj._id,  // Usar el _id de la lista
            material: materialObj._id, // Usar el _id del material
            cantidad,
            observaciones
        });

        await nuevoMaterial.save();
        res.status(201).json(nuevoMaterial);
    } catch (error) {
        res.status(400).json({ msj: error.message });
    }
});


router.get('/', async (req, res) => {
    try {
        // 1. Primero verifica que hay documentos
        const count = await Material.countDocuments();
        if (count === 0) {
            return res.json([]);
        }

        // 2. Obtener datos con populate forzado
        const materiales = await Material.find()
            .populate({
                path: 'lista',
                model: 'Lista',
                select: 'nombreLista nivelEducativo'
            })
            .populate({
                path: 'material',
                model: 'MaterialEscolar',
                select: 'nombre descripcion'
            })
            .lean();

        // 3. Verificación manual de populate
        const resultados = materiales.map(item => {
            // Si el populate falló, intenta cargar manualmente
            if (typeof item.lista === 'string' || item.lista === null) {
                console.warn(`Lista no poblada para documento ${item._id}`);
            }
            if (typeof item.material === 'string' || item.material === null) {
                console.warn(`Material no poblado para documento ${item._id}`);
            }

            return item;
        });

        console.log("Datos finales a enviar:", JSON.stringify(resultados, null, 2));
        res.json(resultados);
    } catch (error) {
        console.error("Error completo:", error);
        res.status(500).json({ 
            success: false,
            message: "Error al obtener materiales",
            error: error.message,
            stack: error.stack
        });
    }
});

module.exports = router;



