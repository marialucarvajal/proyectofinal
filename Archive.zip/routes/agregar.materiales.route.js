const express = require('express');
const router = express.Router();
const Material = require('../models/agregar.materiales');
const Lista = require('../models/registrar.listas'); // Asegúrate de tener el modelo Lista
const MaterialEscolar = require('../models/registrar.materiales');

// Ruta POST para agregar materiales
router.post('/', async (req, res) => {
    const { lista, material, cantidad, observaciones } = req.body;

    if (!lista || !material || !cantidad) {
        return res.status(400).json({ msj: 'Por favor llenar los campos son obligatorios.' });
    }

    try {
        // Buscar la lista por ID
        const listaObj = await Lista.findById(lista);
        if (!listaObj) {
            return res.status(400).json({ msj: 'Lista no encontrada.' });
        }

        // Buscar el material por ID
        const materialObj = await MaterialModelo.findById(material);
        if (!materialObj) {
            return res.status(400).json({ msj: 'Material no encontrado.' });
        }

        const nuevoMaterial = new Material({
            lista: listaObj._id,  // Usar el _id de la lista
            material: materialObj._id, // Usar el _id del material
            cantidad,
            observaciones
        });

        await nuevoMaterial.save();
        res.status(201).json(nuevoMaterial);
    } catch (error) {
        res.status(400).json({ msj: error.message });
    }
});


router.get('/', async (req, res) => {
    try {
        console.log("Intentando obtener materiales...");
        
        // Verificar conexión a la base de datos
        if (mongoose.connection.readyState !== 1) {
            throw new Error('No hay conexión a MongoDB');
        }

        // Verificar colecciones existentes
        const collections = await mongoose.connection.db.listCollections().toArray();
        console.log("Colecciones disponibles:", collections.map(c => c.name));

        // Obtener datos con populate
        const materiales = await mongoose.model('Material').find()
            .populate({
                path: 'lista',
                select: 'nombreLista nivelEducativo'
            })
            .populate({
                path: 'material',
                select: 'nombre descripcion'
            })
            .lean();

        console.log(`Se encontraron ${materiales.length} materiales`);
        console.log("Primer material:", materiales[0] || "No hay materiales");
        
        res.json(materiales);
    } catch (error) {
        console.error("Error completo en GET /:", error);
        res.status(500).json({ 
            success: false,
            message: "Error al obtener materiales",
            error: error.message,
            stack: error.stack
        });
    }
});

router.get('/test', async (req, res) => {
    const testData = {
      _id: "999999999999999999999999",
      lista: { 
        _id: "6807ef2bf2b141f216137de3",
        nombreLista: "LISTA DE PRUEBA", 
        nivelEducativo: "PRUEBA NIVEL" 
      },
      material: { 
        _id: "6807e8a21363f8a047671920",
        nombre: "MATERIAL DE PRUEBA", 
        descripcion: "DESCRIPCION DE PRUEBA" 
      },
      cantidad: 100,
      observaciones: "Esto es una prueba de funcionamiento"
    };
    res.json([testData]); // Devuelve un array con un solo elemento
  });

module.exports = router;



