const express = require('express');
const router = express.Router();
const Categoria = require('../models/registrar.categorias'); 

router.post('/', async (req, res) => {
    try {
        const { nombre, descripcion } = req.body;
        if (!nombre || !descripcion) {
            return res.status(400).json({ message: 'Nombre y descripción son requeridos' });
        }

        const nuevaCategoria = new Categoria({ nombre, descripcion });
        const categoriaGuardada = await nuevaCategoria.save();
        res.status(201).json(categoriaGuardada);
    } catch (error) {
        console.error("Error al guardar el material:", error);  
        res.status(500).json({ message: `Error al crear el material: ${error.message}` });
    }
});

router.get('/', async (req, res) => {
    try {
        const categorias = await Categoria.find();
        res.status(200).json(categorias);
    } catch (error) {
        res.status(500).json({ message: `Error al obtener las categorías: ${error.message}` });
    }
});

module.exports = router;
