const express = require('express');
const router = express.Router();
const ListaUtiles = require('../models/registrar.listas');

router.post('/', async (req, res) => {
    console.log("BODY recibido:", req.body)
    const { lista, nivelEducativo, fechaCreacion, estado } = req.body;

    if (!lista || !nivelEducativo || !fechaCreacion || !estado) {
        return res.status(400).json({ msj: 'Por favor llenar todos los campos obligatorios: lista, nivelEducativo, fechaCreacion, y estado.' });
    }

    try {
        const nuevaLista = new ListaUtiles({ lista, nivelEducativo, fechaCreacion, estado });
        await nuevaLista.save();
        res.status(201).json(nuevaLista);
    } catch (error) {
        res.status(400).json({ msj: error.message });
    }
});

router.get('/', async (req, res) => {
    try {
        const listasUtiles = await ListaUtiles.find().select('-__v');
        res.json(listasUtiles);
    } catch (error) {
        res.status(500).json({ msj: error.message });
    }
});

module.exports = router;
