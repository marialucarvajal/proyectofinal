const express = require('express');
const router = express.Router();

const materialEscolar = require('../models/registrar.materiales');
const Categoria = require('../models/registrar.categorias');

router.post('/', async (req, res) => {
    const { nombre, descripcion, categoria, unidadMedida, estado } = req.body;
    console.log("Datos recibidos en el backend:", req.body);  

    if (!nombre || !descripcion || !categoria || !unidadMedida || estado === undefined) {
        return res.status(400).json({ msj: "Todos los campos son obligatorios" });
    }

    try {
        const categoriaExistente = await Categoria.findById(categoria);
        if (!categoriaExistente) {
            return res.status(400).json({ msj: "Categoría no válida" });
        }

        const nuevoMaterial = new materialEscolar({
            nombre,
            descripcion,
            categoria,
            unidadMedida,
            estado
        });

        await nuevoMaterial.save(); 
        res.status(201).json(nuevoMaterial); 
    } catch (error) {
        console.error("Error al registrar material:", error); 
        res.status(500).json({ msj: error.message });
    }
});

router.get('/', async (req, res) => {
    try {
        const materiales = await materialEscolar.find().populate({
            path: 'categoria',
            select: 'nombre'
        });
        console.log("Materiales obtenidos:", materiales);  
        res.json(materiales);
    } catch (error) {
        console.error("Error al obtener materiales:", error);
        res.status(500).json({ msj: error.message });
    }
});

module.exports = router;

