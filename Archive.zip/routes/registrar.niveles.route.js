const express = require('express');
const router = express.Router();
const Nivel = require('../models/registrar.niveles');


router.post('/', async (req, res) => {
     const { nivel, descripcion, estado } = req.body;
     if (!nivel || !descripcion || !estado) {
        return res.status(400).json({ msj: 'Todos los campos son obligatorios' });
    }
     try {
        const nuevoNivel = new Nivel({ nivel, descripcion, estado });
            await nuevoNivel.save();
            res.status(201).json(nuevoNivel);
        } catch (error) {
            res.status(400).json({ msj: error.message });
        }
    });


    router.get('/', async(req,res) =>{
        try{
            const niveles = await Nivel.find();
            res.json(niveles);
        }catch(error){
            res.status(500).json({msj: error.message});
        }
    });


module.exports = router;