const express= require ('express');
const router = express.Router();
const Usuario = require('../models/registrar.usuario');

router.post('/', async(req,res)=>{
    const { correo, cedula, nombre, contrasena, rol, estadoCuenta } = req.body;

    if (!nombre || !cedula || !correo || !contrasena || !rol || !estadoCuenta) {
        return res.status(400).json({ msj: 'Todos los campos son obligatorios' });
    }

    const nuevoUsuario = new Usuario({ nombre, cedula, correo, contrasena, rol, estadoCuenta });
    await nuevoUsuario.save();
    res.status(201).json(nuevoUsuario);
});

router.get('/', async(req,res)=>{
    try{ 
        const usuarios = await Usuario.find();
        res.json(usuarios);

    }catch(error){ 
        res.status(500).json({msj: error.message});
     } 

});


module.exports = router;