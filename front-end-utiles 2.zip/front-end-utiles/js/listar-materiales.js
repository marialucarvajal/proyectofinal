const tablaMateriales = document.getElementById('tablaMateriales');

async function cargarTabla() {
    fetch('http://localhost:4000/registrarMateriales')
    .then(response => response.json())
    .then(materiales => {
        const tablaMateriales = document.getElementById('tablaMateriales');
        tablaMateriales.innerHTML = ''; 

        materiales.forEach(material => {
            const row = document.createElement('tr');

            const categoriaNombre = material.categoria ? material.categoria.nombre : 'Sin categoría';

            row.innerHTML = `
                <td>${material.nombre}</td>
                <td>${material.descripcion}</td>
                <td>${categoriaNombre}</td>  <!-- Mostrar el nombre de la categoría -->
                <td>${material.unidadMedida}</td>
                <td>${material.estado ? 'Disponible' : 'No disponible'}</td>
            `;

            tablaMateriales.appendChild(row);
        });
    })
    .catch(error => {
        console.error('Error al obtener los materiales:', error);
    });
}

cargarTabla();