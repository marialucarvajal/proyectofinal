const tablaMateriales = document.getElementById('tblMateriales').querySelector('tbody');

async function cargarTabla() {
    try {
        const response = await fetch('http://localhost:4000/agregarMateriales');
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        console.log("Datos recibidos del servidor:", data);
        
        const tbody = document.getElementById('tblMateriales').querySelector('tbody');
        tbody.innerHTML = '';
        
        if (!data || data.length === 0) {
            tbody.innerHTML = '<tr><td colspan="4" class="text-center">No hay materiales registrados</td></tr>';
            return;
        }

        data.forEach(item => {
            const row = document.createElement('tr');
            
            // Manejo a prueba de errores para lista
            let listaInfo = 'Lista no disponible';
            if (item.lista) {
                if (typeof item.lista === 'object') {
                    listaInfo = `${item.lista.nombreLista || 'Sin nombre'} (${item.lista.nivelEducativo || 'Sin nivel'})`;
                } else if (typeof item.lista === 'string') {
                    listaInfo = `ID: ${item.lista}`;
                }
            }
            
            // Manejo a prueba de errores para material
            let materialInfo = 'Material no disponible';
            if (item.material) {
                if (typeof item.material === 'object') {
                    materialInfo = `${item.material.nombre || 'Sin nombre'} - ${item.material.descripcion || ''}`.trim();
                } else if (typeof item.material === 'string') {
                    materialInfo = `ID: ${item.material}`;
                }
            }
            
            row.innerHTML = `
                <td>${listaInfo}</td>
                <td>${materialInfo}</td>
                <td>${item.cantidad || '0'}</td>
                <td>${item.observaciones || 'Sin observaciones'}</td>
            `;
            
            tbody.appendChild(row);
        });
    } catch (error) {
        console.error("Error al cargar materiales:", error);
        const tbody = document.getElementById('tblMateriales').querySelector('tbody');
        tbody.innerHTML = `
            <tr>
                <td colspan="4" class="text-center text-danger">
                    Error al cargar datos: ${error.message}
                </td>
            </tr>
        `;
    }
}

// Cargar tabla cuando el DOM esté listo
if (document.readyState === 'complete') {
    cargarTabla();
} else {
    document.addEventListener('DOMContentLoaded', cargarTabla);
}
