document.addEventListener("DOMContentLoaded", function () {
    const listaInput = document.getElementById("txtLista");
    const nivelEducativoInput = document.getElementById("txtNivelEducativo");
    const fechaCreacionInput = document.getElementById("txtFechaCreacion");
    const estadoInput = document.getElementById("txtEstado");
    const btnSubmit = document.getElementById("btnSubmit");

    const inputs = document.querySelectorAll('input[required], textarea[required], select[required]');

    function validar(event) {
        event.preventDefault();
        let error = false;
        inputs.forEach(input => {
            if (input.value.trim() === "") {
                error = true;
                input.style.borderColor = "red";
            } else {
                input.style.borderColor = "";
            }
        });

        if (!error) {
            registrarLista();
        } else {
            alert('Por favor, complete todos los campos.');
        }
    }

    function registrarLista() {
        const datosLista = {
            lista: listaInput.value,
            nivelEducativo: nivelEducativoInput.value,  
            fechaCreacion: fechaCreacionInput.value,
            estado: estadoInput.checked ? "activo" : "inactivo"
        };
        console.log("Nivel educativo seleccionado:", nivelEducativoInput.value);

        fetch("http://localhost:4000/registrarListas", {
            method: "POST",
            headers: {
                "Content-type": "application/json"
            },
            body: JSON.stringify(datosLista),
            mode: "cors"
        })
        .then(response => {
            if (!response.ok) {
                alert("No se pudo registrar la lista de útiles.");
            } else {
                alert("Lista de útiles registrada exitosamente.");
                limpiarFormulario(); 
            }
        })
        .catch(error => {
            console.error(error);
        });
    }

    function cargarNiveles() {
        fetch("http://localhost:4000/registrarNiveles")
            .then(response => response.json())
            .then(data => {
                console.log("Datos recibidos:", data); 
    
                const select = document.getElementById("txtNivelEducativo");
    
                data.forEach(nivel => {
                    console.log("Nivel:", nivel.nivel);  
                    if (nivel.estado === "activo" || nivel.estado === true) {
                        const option = document.createElement("option");
                        option.value = nivel.nivel;  
                        option.textContent = nivel.nivel;  
                        select.appendChild(option);
                    }
                });
            })
            .catch(error => {
                console.error("Error al cargar los niveles:", error);
            });
    }

    function limpiarFormulario() {
        listaInput.value = "";
        nivelEducativoInput.value = "";
        fechaCreacionInput.value = "";
        estadoInput.checked = false;

        inputs.forEach(input => input.style.borderColor = "");
    }

    cargarNiveles();
    btnSubmit.addEventListener("click", validar);
});
