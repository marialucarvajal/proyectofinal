document.addEventListener("DOMContentLoaded", function () {
    const inputLista = document.getElementById("txtLista");
    const inputMaterial = document.getElementById("txtMaterial");
    const inputCantidad = document.getElementById("txtCantidad");
    const inputObservaciones = document.getElementById("txtObservaciones");
    const btnGuardar = document.getElementById("btnGuardar");
    const inputs = document.querySelectorAll("input[required], select[required]");

    cargarListas();
    cargarMateriales();

    function cargarListas() {
        fetch("http://localhost:4000/registrarListas")
            .then(response => response.json())
            .then(data => {
                console.log("Listas cargadas:", data);
                inputLista.innerHTML = '<option value="">Seleccione la Lista</option>';
                data.forEach(lista => {
                    if (lista.estado === "activo") {
                        const option = document.createElement("option");
                        option.value = lista._id;  // ID de la lista
                        option.textContent = lista.nombreLista;  // Nombre visible de la lista
                        inputLista.appendChild(option);
                    }
                });
            })
            .catch(error => {
                console.error("Error al cargar las listas:", error);
            });
    }
    
    function cargarMateriales() {
        fetch("http://localhost:4000/registrarMateriales")
            .then(response => response.json())
            .then(data => {
                console.log("Materiales cargados:", data);
                inputMaterial.innerHTML = '<option value="">Seleccione el Material</option>';
                data.forEach(material => {
                    const option = document.createElement("option");
                    option.value = material._id;  // ID del material
                    option.textContent = material.nombre;  // Nombre visible del material
                    inputMaterial.appendChild(option);
                });
            })
            .catch(error => {
                console.error("Error al cargar los materiales:", error);
            });
    }

    // Validar que todos los campos estén llenos antes de enviar los datos
    function validar() {
        let error = false;
    
        console.log("Lista seleccionada:", inputLista.value);
        console.log("Material seleccionado:", inputMaterial.value);
    
        inputs.forEach(input => {
            if (input.value.trim() === "") {
                input.style.borderColor = "red";
                error = true;
            } else {
                input.style.borderColor = "";
            }
        });
    
        if (inputLista.value === "" || inputMaterial.value === "") {
            alert("Por favor, seleccione una lista y un material.");
            error = true;
        }
    
        if (error) {
            alert("Por favor, complete todos los campos.");
        } else {
            agregarMaterial();
        }
    }

    function agregarMaterial() {
        const cantidad = parseInt(inputCantidad.value, 10);
        if (isNaN(cantidad) || cantidad <= 0) {
            alert("La cantidad debe ser un número mayor que 0.");
            return;
        }
    
        const datosMaterial = {
            nombreLista: inputLista.value,  // ID de la lista
            material: inputMaterial.value,  // ID del material
            cantidad: cantidad,
            observaciones: inputObservaciones.value,
            nivelEducativo: "Primaria",
            fechaCreacion: new Date(),
            estado: "activo"
        };
    
        console.log("Datos a enviar al backend:", JSON.stringify(datosMaterial));
    
        fetch("http://localhost:4000/agregarMateriales", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(datosMaterial)
        })
        .then(response => {
            if (!response.ok) {
                console.error("Error en la respuesta del servidor:", response.statusText);
                alert("No se pudo registrar el material.");
            } else {
                alert("Se registró el material exitosamente.");
                limpiarFormulario();
            }
        })
        .catch(error => {
            console.error("Error al agregar material:", error);
        });
    }
    

    // Limpiar el formulario después de registrar el material
    function limpiarFormulario() {
        inputLista.value = "";
        inputMaterial.value = "";
        inputCantidad.value = "";
        inputObservaciones.value = "";
    }

    // Agregar el evento al botón de guardar
    btnGuardar.addEventListener("click", validar);
});


