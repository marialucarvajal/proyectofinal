document.addEventListener("DOMContentLoaded", () => {
    const tablaListas = document.getElementById("tablaListas");

    async function listarListasUtiles() {
        try {
            const response = await fetch("http://localhost:4000/registrarListas", {
                method: "GET",
                headers: { "Content-Type": "application/json" },
                mode: "cors"
            });

            if (!response.ok) {
                throw new Error("Error al obtener las listas de útiles");
            }

            const listas = await response.json();
            tablaListas.innerHTML = "";

            listas.forEach(lista => {
                const fila = document.createElement("tr");

                const celdaNombre = document.createElement("td");
                celdaNombre.textContent = lista.nombreLista;

                const celdaNivel = document.createElement("td");
                celdaNivel.textContent = lista.nivelEducativo || 'Nivel no encontrado';

                const celdaFecha = document.createElement("td");
                const fecha = new Date(lista.fechaCreacion);
                const opcionesFecha = { year: 'numeric', month: 'long', day: 'numeric' };
                celdaFecha.textContent = fecha.toLocaleDateString('es-CR', opcionesFecha);

                const celdaEstado = document.createElement("td");
                celdaEstado.textContent = lista.estado;

                fila.appendChild(celdaNombre);
                fila.appendChild(celdaNivel);
                fila.appendChild(celdaFecha);
                fila.appendChild(celdaEstado);

                tablaListas.appendChild(fila);
            });

        } catch (error) {
            console.error("Error:", error);
            alert("No se pudieron cargar las listas de útiles.");
        }
    }

    listarListasUtiles();
});