document.addEventListener("DOMContentLoaded", () => {
    const tablaNiveles = document.getElementById("tablaNiveles");
  
    async function listarNiveles() {
      try {
        const response = await fetch("http://localhost:4000/registrarNiveles", {
          method: "GET",
          headers: { "Content-Type": "application/json" },
          mode: "cors"
        });
  
        if (!response.ok) {
          throw new Error("Error al obtener niveles");
        }
  
        const niveles = await response.json();
        tablaNiveles.innerHTML = "";
  
        niveles.forEach(nivel => {
          const fila = document.createElement("tr");
  
          const celdaNombre = document.createElement("td");
          celdaNombre.textContent = nivel.nivel;  
  
          const celdaDescripcion = document.createElement("td");
          celdaDescripcion.textContent = nivel.descripcion; 
  
          const celdaEstado = document.createElement("td");
          celdaEstado.textContent = nivel.estado;  
  
          fila.appendChild(celdaNombre);
          fila.appendChild(celdaDescripcion);
          fila.appendChild(celdaEstado);
  
          tablaNiveles.appendChild(fila);
        });
      } catch (error) {
        console.error("Error:", error);
        alert("No se pudieron cargar los niveles.");
      }
    }
  
    listarNiveles();
  });