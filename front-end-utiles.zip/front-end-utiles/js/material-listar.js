function formatMaterial(material) {
    if (!material) return '<span class="text-muted">No especificado</span>';
    return `
      <div class="fw-semibold">${material.nombre}</div>
      ${material.descripcion ? `<small class="text-muted">${material.descripcion}</small>` : ''}
    `;
  }
  
  async function cargarTabla() {
    const tbody = document.getElementById('tblMateriales').getElementsByTagName('tbody')[0];
    tbody.innerHTML = '<tr><td colspan="4" class="text-center py-3"><div class="spinner-border text-primary"></div></td></tr>';
  
    try {
      const response = await fetch('http://localhost:4000/agregarMateriales');
      
      if (!response.ok) throw new Error(`Error ${response.status}`);
      
      const data = await response.json();
      
      tbody.innerHTML = data.length ? '' : `
        <tr>
          <td colspan="4" class="text-center py-4">
            <i class="bi bi-inbox"></i> No hay materiales registrados
          </td>
        </tr>
      `;
  
      data.forEach(item => {
        const row = tbody.insertRow();
        row.innerHTML = `
          <td>
            <div class="fw-bold">${item.lista.nombreLista}</div>
            <small class="text-muted">${item.lista.nivelEducativo}</small>
          </td>
          <td>${formatMaterial(item.material)}</td>
          <td class="text-center">${item.cantidad}</td>
          <td>${item.observaciones || '<span class="text-muted">Ninguna</span>'}</td>
        `;
      });
    } catch (error) {
      tbody.innerHTML = `
        <tr>
          <td colspan="4" class="text-center text-danger py-4">
            <i class="bi bi-exclamation-triangle"></i> ${error.message}
            <button onclick="cargarTabla()" class="btn btn-sm btn-link">Reintentar</button>
          </td>
        </tr>
      `;
      console.error('Error:', error);
    }
  }
  
  // Iniciar
  document.addEventListener('DOMContentLoaded', cargarTabla);





