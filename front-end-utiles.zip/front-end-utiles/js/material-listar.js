async function cargarTabla() {
    const tbody = document.querySelector('#tblMateriales tbody');
    tbody.innerHTML = '<tr><td colspan="4" class="text-center"><div class="spinner-border"></div></td></tr>';

    try {
        const response = await fetch('http://localhost:4000/agregarMateriales');
        
        if (!response.ok) {
            throw new Error(`Error ${response.status}: ${response.statusText}`);
        }
        
        const data = await response.json();
        console.log('Datos recibidos:', data);
        
        tbody.innerHTML = '';
        
        if (!data.length) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="4" class="text-center text-muted py-4">
                        <i class="bi bi-inbox"></i> No hay materiales registrados
                        <div class="mt-2">
                            <a href="agregar-materiales.html" class="btn btn-sm btn-primary">
                                <i class="bi bi-plus-circle"></i> Agregar material
                            </a>
                        </div>
                    </td>
                </tr>
            `;
            return;
        }

        data.forEach(item => {
            const row = document.createElement('tr');
            row.className = 'align-middle';

            const listaCell = document.createElement('td');
            listaCell.innerHTML = `
                <div class="fw-bold">${item.lista?.nombreLista || 'Lista no disponible'}</div>
                <small class="text-muted">${item.lista?.nivelEducativo || ''}</small>
            `;
            
            const materialCell = document.createElement('td');
            materialCell.innerHTML = `
                <div class="fw-bold">${item.material?.nombre || 'Material no disponible'}</div>
                ${item.material?.descripcion ? `<small class="text-muted">${item.material.descripcion}</small>` : ''}
            `;
            
            const cantidadCell = document.createElement('td');
            cantidadCell.textContent = item.cantidad || '0';
            cantidadCell.className = 'text-center';
            
            const obsCell = document.createElement('td');
            obsCell.textContent = item.observaciones || 'Sin observaciones';
            
            row.append(listaCell, materialCell, cantidadCell, obsCell);
            tbody.appendChild(row);
        });
    } catch (error) {
        console.error('Error al cargar tabla:', error);
        tbody.innerHTML = `
            <tr>
                <td colspan="4" class="text-center text-danger py-4">
                    <i class="bi bi-exclamation-triangle-fill"></i> Error al cargar datos
                    <div class="mt-2">
                        <button onclick="cargarTabla()" class="btn btn-sm btn-outline-danger">
                            <i class="bi bi-arrow-clockwise"></i> Reintentar
                        </button>
                    </div>
                    <small class="d-block mt-1">${error.message}</small>
                </td>
            </tr>
        `;
    }
}

document.addEventListener('DOMContentLoaded', cargarTabla);





