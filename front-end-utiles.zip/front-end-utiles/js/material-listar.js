async function cargarTabla() {
    fetch('http://localhost:4000/registrarMateriales')
    .then(response => response.json())
    .then(data => {
        console.log('Respuesta recibida:', data);

        // Asegurarse de que la respuesta sea un arreglo
        const materiales = Array.isArray(data) ? data : [data];

        const tablaMateriales = document.getElementById('tblMateriales').querySelector('tbody');
        tablaMateriales.innerHTML = ''; // Limpiar la tabla antes de llenarla

        materiales.forEach(material => {
            console.log(material); // Mostrar la estructura de cada material

            // Comprobación de que el material tiene la estructura esperada
            const nombreLista = material.lista ? material.lista.nombreLista : 'Sin lista';
            const nombreMaterial = material.material && material.material.nombre !== 'No disponible' ? material.material.nombre : 'Sin nombre';
            const descripcionMaterial = material.material && material.material.descripcion ? material.material.descripcion : 'Sin descripción';
            const cantidad = material.cantidad || 'Sin cantidad';
            const observaciones = material.observaciones || 'Sin observaciones';
            const estado = material.estado ? 'Disponible' : 'No disponible';

            // Crear una nueva fila de la tabla
            const row = document.createElement('tr');

            // Insertar los valores en las celdas
            row.innerHTML = `
                <td>${nombreLista}</td>
                <td>${nombreMaterial}</td>
                <td>${descripcionMaterial}</td>
                <td>${cantidad}</td>
                <td>${observaciones}</td>
                <td>${estado}</td>
            `;

            // Agregar la fila a la tabla
            tablaMateriales.appendChild(row);
        });
    })
    .catch(error => {
        console.error('Error al obtener los materiales:', error);
    });
}

cargarTabla();





