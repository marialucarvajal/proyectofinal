const tablaMateriales = document.getElementById('tblMateriales').querySelector('tbody');

async function cargarTabla() {
    try {
        const response = await fetch('http://localhost:4000/agregarMateriales');
        if (!response.ok) throw new Error(`Error HTTP ${response.status}`);
        
        const data = await response.json();
        console.log('Datos crudos:', data);

        const tbody = document.querySelector('#tblMateriales tbody');
        tbody.innerHTML = '';

        if (!data.length) {
            tbody.innerHTML = '<tr><td colspan="4">No hay materiales registrados</td></tr>';
            return;
        }

        data.forEach(item => {
            const row = document.createElement('tr');
            
            // Manejo seguro de lista
            let listaInfo = 'Lista no disponible';
            if (item.lista) {
                if (typeof item.lista === 'object') {
                    listaInfo = `${item.lista.nombreLista || 'Sin nombre'} (${item.lista.nivelEducativo || 'Sin nivel'})`;
                } else {
                    listaInfo = `ID: ${item.lista}`;
                }
            }

            // Manejo seguro de material
            let materialInfo = 'Material no disponible';
            if (item.material) {
                if (typeof item.material === 'object') {
                    materialInfo = `${item.material.nombre || 'Sin nombre'} - ${item.material.descripcion || ''}`;
                } else {
                    materialInfo = `ID: ${item.material}`;
                }
            }

            row.innerHTML = `
                <td>${listaInfo}</td>
                <td>${materialInfo}</td>
                <td>${item.cantidad || '0'}</td>
                <td>${item.observaciones || 'Sin observaciones'}</td>
            `;
            tbody.appendChild(row);
        });
    } catch (error) {
        console.error('Error:', error);
        document.querySelector('#tblMateriales tbody').innerHTML = `
            <tr><td colspan="4" class="text-danger">Error: ${error.message}</td></tr>
        `;
    }
}