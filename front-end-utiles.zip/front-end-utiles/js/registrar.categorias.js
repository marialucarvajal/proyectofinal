const API_URL = 'http://localhost:4000/registrarCategorias';

document.addEventListener("DOMContentLoaded", function () {
    const nombreInput = document.getElementById("nombreCategoria");
    const descripcionInput = document.getElementById("descripcionCategoria");
    const btnGuardar = document.querySelector('.btn-custom');
    const inputs = document.querySelectorAll('input[required]');

    function validar(event) {
        event.preventDefault();
        let error = false;
        
        inputs.forEach(input => {
            if (input.value.trim() === "") {
                error = true;
                input.style.borderColor = "red";
            } else {
                input.style.borderColor = "";
            }
        });

        if (!error) {
            registrarCategoria();
        } else {
            alert('Por favor, complete todos los campos.');
        }
    }

    async function registrarCategoria() {
        const datosCategoria = {
            nombre: nombreInput.value,
            descripcion: descripcionInput.value
        };

        try {
            const response = await fetch(API_URL, {
                method: "POST",
                headers: {
                    "Content-type": "application/json"
                },
                body: JSON.stringify(datosCategoria),
                mode: "cors"
            });

            if (!response.ok) {
                alert("No se pudo registrar la categoría.");
            } else {
                alert("Se registró la categoría exitosamente.");
                document.getElementById("categoriaForm").reset();
                cargarCategorias();
            }
        } catch (error) {
            console.error("Error al registrar la categoría:", error);
        }
    }

    btnGuardar.addEventListener('click', validar);
});
