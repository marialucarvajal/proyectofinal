const inputNombre = document.getElementById('txtNombre');
const inputDescripcion = document.querySelector('#txtDescripcion');
const inputCategoria = document.querySelector('#txtCategoria');
const inputUnidadM = document.querySelector('#txtUnidad');
const inputEstado = document.querySelector('#txtEstado');

const btnEnviar = document.querySelector('#btn-submit');

const inputsRequeridos = document.querySelectorAll('input[required]');

document.addEventListener('DOMContentLoaded', function () {
    fetch('http://localhost:4000/registrarCategorias')  
    .then(response => response.json())
    .then(categorias => {
        const selectCategoria = document.getElementById('txtCategoria');
        
        selectCategoria.innerHTML = ''; 

        const optionDefault = document.createElement('option');
        optionDefault.value = '';
        optionDefault.textContent = 'Selecciona una categoría';
        selectCategoria.appendChild(optionDefault);
        
        categorias.forEach(categoria => {
            if (categoria.nombre && categoria._id) { 
                const option = document.createElement('option');
                option.value = categoria._id;  
                option.textContent = categoria.nombre;
                selectCategoria.appendChild(option);
            }
        });
    })
    .catch(error => {
        console.error('Error al obtener las categorías:', error);
    });
})

function validar() {
    let error = false;
    for (let i = 0; i < inputsRequeridos.length; i++) {
        if (inputsRequeridos[i].value == '') {
            error = true;
            inputsRequeridos[i].style.borderColor = "red"; 
        } else {
            inputsRequeridos[i].style.borderColor = ""; 
        }
    }

    if (error == false) {
        registrarMaterial();  
    }
}

async function registrarMaterial() {
    const datosMateriales = {
        nombre: inputNombre.value.trim(),
        descripcion: inputDescripcion.value.trim(),
        categoria: inputCategoria.value, 
        unidadMedida: inputUnidadM.value.trim(),
        estado: inputEstado.checked,
    };

    console.log(datosMateriales);  

    try {
        const response = await fetch('http://localhost:4000/registrarMateriales', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(datosMateriales),
        });

        if (!response.ok) {
            alert('No se pudo registrar el material escolar');
        } else {
            alert('Registro creado con éxito');
            inputNombre.value = "";
            inputDescripcion.value = "";
            inputCategoria.value = "";
            inputUnidadM.value = "";
            inputEstado.checked = false;
        }
    } catch (error) {
        console.log('Error al registrar el material:', error);
    }
}

btnEnviar.addEventListener('click', validar);

