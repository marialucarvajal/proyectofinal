document.addEventListener("DOMContentLoaded", function () {
    const nombreInput = document.getElementById("nombreNivel");
    const descripcionInput = document.getElementById("descripcionNivel");
    const estadoInput = document.getElementById("estadoNivel");
    const btnGuardar = document.getElementById('btnGuardar');

    const inputs = document.querySelectorAll('input[required], textarea[required], select[required]');

    function validar(event) {
        event.preventDefault();
        let error = false;
        inputs.forEach(input => {
            if (input.value.trim() === "") {
                error = true;
                input.style.borderColor = "red";
            } else {
                input.style.borderColor = "";
            }
        });

        if (!error) {
            registrarNivel();
        } else {
            alert('Por favor, complete todos los campos.');
        }
    }

    function registrarNivel() {
        const datosNivel = {
            nivel: nombreInput.value,
            descripcion: descripcionInput.value,
            estado: estadoInput.value
        };
        
        console.log(datosNivel);

        fetch("http://localhost:4000/registrarNiveles", {
            method: "POST",
            headers: {
                "Content-type": "application/json"
            },
            body: JSON.stringify(datosNivel),
            mode: "cors"
        })
        .then(response => {
            if (!response.ok) {
                alert("No se pudo registrar el nivel.");
            } else {
                alert("Se registró el nivel exitosamente.");
            }
        })
        .catch(error => {
            console.error(error);
        });
    }

    btnGuardar.addEventListener('click', validar);
});
