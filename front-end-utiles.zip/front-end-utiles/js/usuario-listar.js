const tablaUsuarios = document.getElementById('tbl-Usuarios').querySelector('tbody');


async function cargarTabla(){
    fetch('http://localhost:4000/registrarUsuario', {
        method : 'GET',
        headers: {
            'Content-Type': 'application/json'
        }
    })
    .then(response => response.json())
    .then(data => {
        tablaUsuarios.innerHTML = '';
        data.forEach(usuario => {
            const fila = document.createElement('tr');
            fila.innerHTML = `
            <td> ${usuario.correo} </td>
            <td> ${usuario.cedula} </td>
            <td> ${usuario.nombre} </td>
            <td> ${usuario.rol} </td>
            <td> ${usuario.estadoCuenta} </td>
            `;
            tablaUsuarios.appendChild(fila);    
        });
    
    })
}

cargarTabla()