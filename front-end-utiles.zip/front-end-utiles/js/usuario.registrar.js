const inputCorreo = document.getElementById("txtCorreo");
const inputCedula = document.querySelector("#txtCedula");
const inputNombre = document.querySelector("#txtNombre");
const inputContrasena = document.querySelector("#txtContrasena");
const inputConfirmarContrasena = document.getElementById("txtconfirmarContrasena");
const inputRol = document.getElementById("txtRol");
const inputEstadoCuenta = document.getElementById("txtEstadoCuenta");
const btnGuardar = document.getElementById('btnGuardar');

const inputs = document.querySelectorAll('input[required]');

function validar(){
    let error = false;

    inputs.forEach(input => input.style.borderColor = "");

    for(let i = 0; i < inputs.length; i++){
        if (inputs[i].value.trim() === "") {
            error = true;
            inputs[i].style.borderColor = "red"; 
            alert(`El campo "${inputs[i].placeholder || inputs[i].name}" es obligatorio.`);
            break;
        }
    }

    if (inputCedula.value.length !== 9 || isNaN(inputCedula.value)) {
        inputCedula.style.borderColor = "red";
        alert("La cédula debe tener exactamente 9 dígitos numéricos.");
        error = true;
    }

    if (!inputCorreo.value.includes("@")) {
        inputCorreo.style.borderColor = "red";
        alert("El correo debe contener '@'.");
        error = true;
    }

    if (inputContrasena.value.length < 8) {
        inputContrasena.style.borderColor = "red";
        alert("La contraseña debe tener al menos 8 caracteres.");
        error = true;
    }

    if (inputContrasena.value !== inputConfirmarContrasena.value) {
        inputContrasena.style.borderColor = "red";
        inputConfirmarContrasena.style.borderColor = "red";
        alert("Las contraseñas no coinciden.");
        error = true;
    }

    if(!error){
        agregarUsuario();
    }
}

function agregarUsuario(){
    const datosUsuario = {
        correo: inputCorreo.value,
        cedula: inputCedula.value,
        nombre: inputNombre.value,
        contrasena: inputContrasena.value,
        rol: inputRol.value,
        estadoCuenta: inputEstadoCuenta.value
    };

    fetch("http://localhost:4000/registrarUsuario",{
        method:"POST",
        headers: {
            "Content-type": "application/json"
        },
        body: JSON.stringify(datosUsuario)
    }).then(response => {
        if(!response.ok){
            alert("No se pudo registrar el usuario.");
        }else{
            alert("Se registró el usuario exitosamente.");
        }
    }).catch(error => {
        console.log(error);
    })
}

btnGuardar.addEventListener('click', validar);
